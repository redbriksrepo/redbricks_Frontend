import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-proposals',
  templateUrl: './view-proposals.component.html',
  styleUrls: ['./view-proposals.component.scss']
})
export class ViewProposalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
